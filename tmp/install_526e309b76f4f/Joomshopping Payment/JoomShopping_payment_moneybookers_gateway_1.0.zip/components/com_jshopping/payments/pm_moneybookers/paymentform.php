<script type="text/javascript">
function check_pm_moneybookers(){
    $_('payment_form').submit();
}
</script>
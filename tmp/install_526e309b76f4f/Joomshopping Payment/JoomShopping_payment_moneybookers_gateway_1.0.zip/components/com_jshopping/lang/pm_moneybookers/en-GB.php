<?php

define('_MB_EMAIL', "Payment email");
define('_MB_MERCHANT_ID', 'Merchant ID');
define('_MB_SECRETWORD', 'Moneybookers Secret Word');
define('_MB_TRANSACTION_END', "Order Status for successful transactions");
define('_MB_TRANSACTION_PENDING', "Order Status for Pending Payments");
define('_MB_TRANSACTION_FAILED', "Order Status for failed transactions");

?>
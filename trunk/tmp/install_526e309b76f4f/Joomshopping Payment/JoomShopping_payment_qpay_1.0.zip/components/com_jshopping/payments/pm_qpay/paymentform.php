<script type="text/javascript">
function check_pm_qpay(){
    $_('payment_form').submit();
}
</script>
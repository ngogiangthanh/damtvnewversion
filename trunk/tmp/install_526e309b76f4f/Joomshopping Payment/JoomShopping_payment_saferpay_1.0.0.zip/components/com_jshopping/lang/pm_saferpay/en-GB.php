<?php

define("_Account_ID",'Account ID');
define("_spPassword",'Password (only for the https interface)');
define("_SUCCESS_LINK",'Success link');
define("_FAIL_LINK",'Fail link');
define("_BACK_LINK",'Back link');
define("_NOTIFY_URL",'Notify URL');
?>
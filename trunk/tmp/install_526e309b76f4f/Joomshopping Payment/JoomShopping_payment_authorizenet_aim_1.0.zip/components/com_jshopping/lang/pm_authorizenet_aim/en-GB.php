<?php
define('_Card_Number', 'Card Number');
define('_Expiration_Date', 'Expiration Date');
define('_month', 'Month');
define('_year', 'Year');
define('_Test_Server', 'Test Server');
define('_LOGIN_ID', 'Login ID');
define('_Transaction_Key', 'Transaction Key');
?>
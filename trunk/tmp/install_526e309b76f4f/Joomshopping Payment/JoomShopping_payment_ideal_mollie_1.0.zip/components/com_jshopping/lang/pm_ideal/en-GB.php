<?php

define('_I_TESTMODE', 'TestMode');
define('_I_PARTNERID', 'Partner ID');
define('_I_TRANSACTION_END', "Order Status for successful transactions");
define('_I_TRANSACTION_PENDING', "Order Status for Pending Payments");
define('_I_TRANSACTION_FAILED', "Order Status for failed transactions");
define('_I_SELECT_BANK', "Choose your bank");//Kies uw bank

?>